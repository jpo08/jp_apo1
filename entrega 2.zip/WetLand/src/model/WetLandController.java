package model;

public class WetLandController {
	
	private RWetLand []wetlands;
	private TypeSpecie specieType;
	
	public  WetLandController() {
		
		wetlands = new RWetLand[80];
	}
	
	public boolean registerWetLand(String wetLandname,String ubication, String type, int size, String image, String protectedWet){
		
		boolean stopFlag= false;
		
		RWetLand myWetLand = new RWetLand(wetLandname,ubication,type,size,image,protectedWet);
		
		
		
		for(int i = 0; i<wetlands.length && !stopFlag; i++){
			
			if(wetlands[i]==null){
				
				wetlands[i] = myWetLand;
				stopFlag = true;
			}
		}
		
		return stopFlag;
	}
	
	public String showWetLands(){
		String msg= "";
		
		for(int i = 0; i< wetlands.length; i++) {
			if (wetlands[i] !=null){
				msg+="\n"+(i+1)+"."+wetlands[i].getName();
			}
		}
		return msg;
	}
	
	public boolean registerSpecies(String wetLandID, String name, String cientificName, String migratoryType, int specieType){
		
		boolean stopFlag= false;
		
		
		for(int i = 0; i<wetlands.length && !stopFlag; i++){
			
			if(wetlands[i]==null){
				
				if((i+1+"").equals(wetLandID)){
					stopFlag= wetlands[i].addSpecie (name,cientificName,migratoryType,specieType);
					
				}
				
				
			}
		}
		
		return stopFlag;
	}
	
	public boolean registerEvents(String wetLandID, int day, int month, int year, String eventOwner, double eventValue, String eventDescription){
		
		boolean stopFlag= false;
		
		
		for(int i = 0; i<wetlands.length && !stopFlag; i++){
			
			if(wetlands[i]==null){
				
				if((i+1+"").equals(wetLandID)){
					stopFlag= wetlands[i].addEvent(day,month, year, eventOwner, eventValue, eventDescription);
					
				}
				
				
			}
		}
		
		return stopFlag;
	}
	
	public String findSpecie (String specieFinder) {
		
		String msg = "";
	
		
		for(int i = 0; i<wetlands.length; i++){
			
			if (wetlands[i] !=null){
		
				
					
					if(wetlands[i].getSpecies().equals(specieFinder)){
						
						msg+="\n"+(i+1)+"."+wetlands[i].getName();
					}
					
					
				
			}
		}
		return msg;
	}
	
	
	public String maintenance (int maintenanceYear ){
		String maintenanceCount = "";
		int counter = 0;
		
		for(int i = 0; i<wetlands.length; i++){
			if (wetlands[i] !=null){
				
				for(i = 0; i<wetlands[i].events.length; i++){
					if (wetlands[i].events[i] !=null){
						if (wetlands[i].events[i].getEventDate().getYear()== maintenanceYear){
						 counter++;
				
							maintenanceCount+="\n"+wetlands[i].getName()+"recibio: "+counter+" mantenimientos";
						}
					}
				}
			}
		}
		
		return maintenanceCount;
	}
	
	public String lessFloraSpecies ( ){
		
		String msg = "";
		
		for(int i = 0; i<wetlands.length; i++){
			int counter= 0;
			int counterLessSpecies = 100;
			
			if (wetlands[i] !=null && wetlands[i].species[i] != null){
			
				for( i=i; i<wetlands[i].species.length;){
				
					if (wetlands[i].species[i] !=null){
					
						if (wetlands[i].species[i].getSpecieType()== TypeSpecie.terrestrial_flora || wetlands[i].species[i].getSpecieType() ==  TypeSpecie.aquatic_flora){
							counter++;
						
						} 
					}
					
				
				}
				
				
			}
			
			if (counter<counterLessSpecies){
					counterLessSpecies= counter;
					msg+="\n"+(i+1)+wetlands[i].getName()+" have "+counterLessSpecies + " species";
					
				}
		}
		return msg;
		
	}
	


	
	
	
	
}