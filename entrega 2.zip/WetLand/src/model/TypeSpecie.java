package model;

public enum TypeSpecie {

	terrestrial_flora, aquatic_flora, bird, mammal, aquatic_animal
	
}
